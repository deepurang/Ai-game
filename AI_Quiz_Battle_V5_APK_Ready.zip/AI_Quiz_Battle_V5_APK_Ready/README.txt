AI QUIZ BATTLE V5 - APK READY PROJECT

This is an Android WebView project containing the V5 HTML game.

Important:
- The APK itself is NOT compiled in this package.
- Open/import this project in an Android build environment such as Android Studio or another Android Gradle build service.
- The game is currently offline/standalone. Its leaderboard is device-local; real cloud accounts/global leaderboard require a backend.
- No API key is included.

Project entry:
app/src/main/assets/index.html

Build:
1. Import the folder as an Android Gradle project.
2. Build an APK using the Android build tool.
3. Install the generated APK on your Android phone.

App ID: com.aiquizbattle
Version: 5.0
